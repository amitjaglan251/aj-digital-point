// AJ DIGITAL POINT
// Website JavaScript

document.addEventListener("DOMContentLoaded", function () {

    console.log("AJ DIGITAL POINT Website Loaded Successfully");

});
const searchInput = document.getElementById("serviceSearch");
const serviceCards = document.querySelectorAll(".service-card");

searchInput.addEventListener("input", function () {

    const searchText = this.value.toLowerCase().trim();

    serviceCards.forEach(function (card) {

        const serviceText = card.textContent.toLowerCase();

        if (serviceText.includes(searchText)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }

    });

});